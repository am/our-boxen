# Linkinus Puppet Module for Boxen

## Usage

```puppet
include linkinus
```

## Required Puppet Modules

* boxen

