# TeamViewer for Boxen

Remote control any computer or Mac over the internet within seconds or use TeamViewer for online meetings.

[![Build Status](https://travis-ci.org/singuerinc/puppet-teamviewer.png?branch=master)](https://travis-ci.org/singuerinc/puppet-teamviewer)

## Usage

```puppet
include teamviewer
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.