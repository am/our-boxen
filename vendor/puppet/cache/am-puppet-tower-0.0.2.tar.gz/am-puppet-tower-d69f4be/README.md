# Git Tower Puppet Module for Boxen

[![Build Status](https://travis-ci.org/am/puppet-tower.png?branch=master)](https://travis-ci.org/am/puppet-tower)

Requires the `boxen` puppet module.

## Usage

```puppet
include tower
```

## Developing

Write code.

Run `script/cibuild`.
