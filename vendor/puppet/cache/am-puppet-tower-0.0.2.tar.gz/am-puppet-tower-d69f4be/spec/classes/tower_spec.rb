require 'spec_helper'

describe 'tower' do
  it do
    should contain_package('Tower').with({
      :provider => 'compressed_app',
      :source   => 'http://www.git-tower.com/download',
      :flavor   => 'zip',
    })
  end
end
