# Rdio Puppet Module for Boxen

## Usage

```puppet
include rdio
```

## Required Puppet Modules

None.

## Developing

Write code.

Run `script/cibuild`.
