# Git Tower Puppet Module for Boxen

Requires the `boxen` puppet module.

## Usage

```puppet
include tower
```

## Developing

Write code.

Run `script/cibuild`.
